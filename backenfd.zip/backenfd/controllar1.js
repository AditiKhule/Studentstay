const propertymodel = require('./model1')

const getproperty = async (req, res) => {
    try{
        const data = await propertymodel.find()
        res.status(200). send({data})
    }
    catch(err){
        console.log(err)
    }
}
const getid = async(req , res)=>{
    const {_id} = req.params
    try {
        const data = await propertymodel.findOne({_id})
        res.status(200).send({data})
    } catch (error) {
        res.status(400).send(error)
        
    }
}
const postdata1 = async (req , res) =>{
    const { title,location,price, phoneNumber, email, propertyFeatures,aboutProperty, reviews} = req.body
    try {
        const abc = new propertymodel({
            title, 
            location,
            price,
             phoneNumber, 
             email, 
             propertyFeatures,
             aboutProperty,
              reviews,
               image: req.file.filename

        })
        const data = await abc.save();
        res.status(200).send({data})
    } catch (error) {
        res.status(400).send(error)
    }
}

module.exports ={getproperty, getid, postdata1}