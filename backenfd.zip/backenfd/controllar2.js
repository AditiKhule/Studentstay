
const userprofilemodel = require('./model2')

const userdata = async (req, res) => {
    try{
        const data = await userprofilemodel.find()
        res.status(200).send({data})
    }
    catch(err){
        console.log(err)
    }
}
const getuser = async(req , res)=>{
    const {_id} = req.params
    try {
        const data = await userprofilemodel.findOne({_id})
        res.status(200).send({data})
    } catch (error) {
        res.status(400).send(error)
        
    }
}

const userpost = async(req, res) => {
    const {firstName,
        lastName,email,phoneNumber,dateOfBirth,gender,nationality,address,city,postalCode,state } = req.body
    try {
        const data = new userprofilemodel({
            firstName,
      lastName,
      email,
      phoneNumber,
      photo: req.file.filename,
      dateOfBirth,
      gender,
      nationality,
      address,
      city,
      postalCode,
      state
    })
    const data1 = await data.save();
    res.status(200).send({data1})
} catch (error) {
    res.status(400).send(error)
}
}
const deletedata1 = async(req, res) => {
    try{
        const data = await userprofilemodel.deleteOne({phoneNumber:req.params.phoneNumber})
        if (data.deletedCount > 0){
            res.send("Deleted Successfully")
        }
        else{
            {
                res.send("Not Deleted")
            }
        }
    }
    catch(err){
        console.log(err)
    }
}
const updatedata1 = async (req, res) => {
    try{
        const {email} = req.params
        const lastName= req.body.lastName

        const data = await userprofilemodel.updateOne({
            $set:{
                email, lastName
            }
        })
        if ( data.modifiedCount > 0) {
            res.send("Updated successfully")
        }
        else{
            {
                res.send("Not updated")
            }
        }
    }
    catch(err){
        console.log(err)
    }
}

module.exports = {userdata, getuser, userpost, deletedata1, updatedata1}