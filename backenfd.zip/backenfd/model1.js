const mongoose = require('mongoose')

const propertySchema = mongoose.Schema({
    title: String,
    location:String,
    price: Number,
    phoneNumber: Number,
    email:String,
    propertyFeatures: String,
    aboutProperty: String,
    reviews: String,
    image: String
    
})

module.exports = mongoose.model('properties', propertySchema)