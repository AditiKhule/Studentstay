const mongoose = require('mongoose')



const userSchema = mongoose.Schema({
    firstName:String,
      lastName:String,
      email:String,
      phoneNumber:Number,
      photo:String,
      dateOfBirth:String,
      gender:String,
      nationality:String,
      address:String,
      city:String,
      postalCode:Number,
      state:String

    // firstName: {
    //     type: String,
    //     required: true
    // },
    // lastName: {
    //     type: String,
    //     required: true
    // },
    // email: {
    //     type: String,
    //     required: true,
    //     unique: true,
    //     match: /.+\@.+\..+/
    // },
    // phoneNumber: {
    //     type: Number,
    //     required: true,
    //     unique: true
    // },
    // photo: String,
    // dateOfBirth: {
    //     type: Date,
    //     required: true
    // },
    // gender: {
    //     type: String,
    //     required: true,
    //     enum: ['Male', 'Female', 'Other']
    // },
    // nationality: String,
    // address: String,
    // city: String,
    // postalCode: Number,
    // state: {
    //     type: String,
    //     required: true,
    
    // }
})

module.exports = mongoose.model('userprofile', userSchema)