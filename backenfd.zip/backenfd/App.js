const express = require('express');
const mongoose = require('mongoose');
const route = require('./route');

const app = express();

mongoose.connect("mongodb://0.0.0.0:27017/registration")
  .then(() => console.log("Connected to MongoDB"))
  .catch(err => console.log(err));

  app.use(express.static('public'))
  
const cors = require('cors')
app.use(cors())
app.use(express.json());
app.use('/user', route);

app.get('/abc', (req, res) => {
  res.send("yes, we are on local host 8000");
});

app.listen(8000, () => {
  console.log("Server is running on port 8000");
});
