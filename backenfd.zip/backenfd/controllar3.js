const roommatePreferencesModel = require('./model3');

const getPreferences = async (req, res) => {
    try {
        const data = await roommatePreferencesModel.find();
        res.status(200).send({ data });
    } catch (err) {
        console.log(err);
        res.status(500).send({ error: 'Server error' });
    }
};

const getPreferenceById = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await roommatePreferencesModel.findOne({ _id });
        if (data) {
            res.status(200).send({ data });
        } else {
            res.status(404).send({ error: 'Preference not found' });
        }
    } catch (error) {
        console.log(error);
        res.status(400).send({ error: 'Invalid request' });
    }
};

const createPreference = async (req, res) => {
    const { budget, cleanliness, hobbies, gender, smoking, pets, workSchedule } = req.body;
    try {
        const data = new roommatePreferencesModel({
            budget,
            cleanliness,
            hobbies,
            gender,
            smoking,
            pets,
            workSchedule
        });
        const savedData = await data.save();
        res.status(201).send({ data: savedData });
    } catch (error) {
        console.log(error);
        res.status(400).send({ error: 'Invalid request' });
    }
};

const deletePreferenceById = async (req, res) => {
    const { _id } = req.params;
    try {
        const data = await roommatePreferencesModel.deleteOne({ _id });
        if (data.deletedCount > 0) {
            res.send({ message: 'Deleted successfully' });
        } else {
            res.send({ message: 'Preference not found' });
        }
    } catch (err) {
        console.log(err);
        res.status(500).send({ error: 'Server error' });
    }
};

const updatePreferenceById = async (req, res) => {
    const { _id } = req.params;
    const updates = req.body;

    try {
        const data = await roommatePreferencesModel.updateOne(
            { _id },
            { $set: updates }
        );
        if (data.modifiedCount > 0) {
            res.send({ message: 'Updated successfully' });
        } else {
            res.send({ message: 'Preference not updated or not found' });
        }
    } catch (err) {
        console.log(err);
        res.status(500).send({ error: 'Server error' });
    }
};

module.exports = {
    getPreferences,
    getPreferenceById,
    createPreference,
    deletePreferenceById,
    updatePreferenceById
};
