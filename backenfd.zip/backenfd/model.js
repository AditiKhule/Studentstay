const mongoose = require('mongoose')

const userSchema = mongoose.Schema({
    username:String,
    email:String,
    password:String,
    userType:String,
    firstName:String,
    lastName:String,
    phoneNumber:Number
})

module.exports = mongoose.model('registers', userSchema)