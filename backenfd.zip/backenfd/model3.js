const mongoose = require('mongoose');

const roommatePreferencesSchema = new mongoose.Schema({
    budget: {
        type: String,
        required: true
    },
    cleanliness: {
        type: String,
        required: true
    },
    hobbies: {
        type: String,
        required: true
    },
    gender: {
        type: String,
        required: true
    },
    smoking: {
        type: String,
        required: true
    },
    pets: {
        type: String,
        required: true
    },
    workSchedule: {
        type: String,
        required: true
    }
});

const RoommatePreferences = mongoose.model('RoommatePreferences', roommatePreferencesSchema);

module.exports = RoommatePreferences;
