
const registermodel = require('./model')

const getdata = async (req, res) => {
    try{
        const data = await registermodel.find()
        res.status(200).send({data})
    }
    catch(err){
        console.log(err)
    }
}

const getbyid = async(req , res)=>{
    const {_id} = req.params
    try {
        const data = await registermodel.findOne({_id})
        res.status(200).send({data})
    } catch (error) {
        res.status(400).send(error)
        
    }
}
const postdata = async(req, res) => {
    const { username, email, password,userType, firstName, lastName, phoneNumber} = req.body
    try{
        const data = new registermodel({
            
        username,
        email,
        password,
        userType,
        firstName,
        lastName,
        phoneNumber
    })
    const userdata = await data.save()
    res.send({userdata})
    }
    catch(err){
        console.log(err)
    }
}

const deletedata = async(req, res) => {
    try{
        const data = await registermodel.deleteOne({phoneNumber:req.params.phoneNumber})
        if (data.deletedCount > 0){
            res.send("Deleted Successfully")
        }
        else{
            {
                res.send("Not Deleted")
            }
        }
    }
    catch(err){
        console.log(err)
    }

}

const updatedata = async (req, res) => {
    try{
        const {firstName} = req.params
        const lastName= req.body.lastName
        const data = await registermodel.updateOne({
            $set:{
                firstName, lastName
            }
        })
        if ( data.modifiedCount > 0) {
            res.send("Updated successfully")
        }
        else{
            {
                res.send("Not updated")
            }
        }
    }
    catch(err){
        console.log(err)
    }
}
const logindata =async (req, res) => {
    try{
        const {email} = req.body;
        const {password} = req.body;
        
        const data = await registermodel.findOne({
            email, password
        })
        if (!data){
            res.status(401).send({msg:"User not found"})
        }
        else{
            res.status(200).send({msg:"Login successful", data})
        
        }
    }
    catch(err){
        console.log(err)
    }
}

// const logindata = async (req, res) => {
//     try {
//         const { id } = req.body;
//         const user = await registermodel.findById(id); 
        
//         if (!user) {
//             res.status(401).send({ msg: "User not found" });
//         } else {
//             res.status(200).send({ msg: "Login successful", user }); 
//         }
//     } catch (error) {
//         res.status(400).send(error);
//     }
// };



// const logindata = async (req, res) => {
//     try {
//         const { username, password } = req.body;

//         // Check if the user exists
//         const existingUser = await registermodel.findOne({ username });
//         if (!existingUser) {
//             return res.status(400).send({ msg: "User does not exist" });
//         }

//         // Check if the password is correct
//         const isMatch = await bcrypt.compare(password, existingUser.password);
//         if (!isMatch) {
//             return res.status(400).send({ msg: "Invalid credentials" });
//         }

//         res.status(200).send({ msg: "Login successful", user: existingUser });
//     } catch (error) {
//         res.status(500).send({ msg: "Server error" });
//     }
// };
// const logindata = async (req, res) => {
// try {
//     const { username, password } = req.body;

//     // Check if the user exists
//     const existingUser = await User.findOne({ username });
//     if (!existingUser) {
//         return res.status(400).send({ msg: "User does not exist" });
//     }

//     // Check if the password is correct
//     const isMatch = await bcrypt.compare(password, existingUser.password);
//     if (!isMatch) {
//         return res.status(400).send({ msg: "Invalid credentials" });
//     }

//     res.status(200).send({ msg: "Login successful", user: existingUser });
// } catch (error) {
//     res.status(500).send({ msg: "Server error" });
// }
// }
module.exports = {getdata, postdata, deletedata, updatedata,logindata, getbyid}