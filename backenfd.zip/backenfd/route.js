const express = require('express')

const controllar = require('./controllar')
const controllar1 = require('./controllar1')
const controllar2 = require('./controllar2')
const photoUpload = require('./fileUpload')



const route = express.Router()

// registration and login routes
route.get('/getdata', controllar.getdata)
route.post('/newuser', controllar.postdata)
route.delete('/delete/:phoneNumber', controllar.deletedata)
route.put('/update/:firstName', controllar.updatedata)
// route.get('/login/:username', controllar.logindata)
route.post('/login1', controllar.logindata)
route.get('/getbyid/:_id', controllar.getbyid)


// property routes
route.get('/getproperty', controllar1.getproperty)
route.get('/getid/:_id', controllar1.getid)
route.post('/postdata1',photoUpload.single('image'), controllar1.postdata1)

// user profile routes
route.get('/userdata', controllar2.userdata)
route.get('/getuser/:_id', controllar2.getuser)
route.post('/userpost', photoUpload.single('photo'), controllar2.userpost)
route.delete('/deletedata1/:phoneNumber', controllar2.deletedata1)



module.exports = route
